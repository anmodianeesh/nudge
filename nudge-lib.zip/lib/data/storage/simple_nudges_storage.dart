// lib/data/storage/simple_nudges_storage.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/simple_nudge.dart';
import '../models/nudge_spec.dart';
import '../models/nudge_model.dart';

class SimpleNudgesStorage {
  static const String _key = 'chat_nudges';
  
  static Future<List<SimpleNudge>> getAllNudges() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_key);
    
    if (jsonString == null) return [];
    
    final List<dynamic> jsonList = json.decode(jsonString);
    return jsonList.map((json) => SimpleNudge.fromJson(json)).toList();
  }
  
  static Future<void> addNudge(NudgeSpec spec) async {
    final nudges = await getAllNudges();
    final newNudge = SimpleNudge(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      spec: spec,
      createdAt: DateTime.now(),
      status: SimpleNudgeStatus.active,
    );
    
    nudges.add(newNudge);
    await _saveNudges(nudges);
  }
// Returns the created ID so UI can update state immediately.
static Future<String> addNudgeWithCategoryReturningId(
  NudgeSpec spec,
  NudgeCategory category,
) async {
  final nudges = await getAllNudges();
  final newId = DateTime.now().millisecondsSinceEpoch.toString();

  final newNudge = SimpleNudge(
    id: newId,
    spec: spec,
    createdAt: DateTime.now(),
    status: SimpleNudgeStatus.active,
    category: category,
    isAIGenerated: true,
  );

  nudges.add(newNudge);
  await _saveNudges(nudges);
  return newId;
}

  static Future<void> addNudgeWithCategory(NudgeSpec spec, NudgeCategory category) async {
    final nudges = await getAllNudges();
    final newNudge = SimpleNudge(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      spec: spec,
      createdAt: DateTime.now(),
      status: SimpleNudgeStatus.active,
      category: category,
      isAIGenerated: true,
    );
    
    nudges.add(newNudge);
    await _saveNudges(nudges);
  }

  static Future<List<SimpleNudge>> getNudgesByCategory(NudgeCategory category) async {
    final allNudges = await getAllNudges();
    return allNudges.where((nudge) => nudge.category == category).toList();
  }

  static Future<List<SimpleNudge>> getAINudges() async {
    final allNudges = await getAllNudges();
    return allNudges.where((nudge) => nudge.isAIGenerated).toList();
  }
  
  static Future<void> _saveNudges(List<SimpleNudge> nudges) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = nudges.map((nudge) => nudge.toJson()).toList();
    await prefs.setString(_key, json.encode(jsonList));
  }

  // Convert SimpleNudge to complex Nudge for integration with existing screens
  static Nudge convertToComplexNudge(SimpleNudge simpleNudge, String userId) {
    return Nudge(
      id: simpleNudge.id,
      title: simpleNudge.spec.title,
      description: simpleNudge.spec.microStep,
      category: _getCategoryString(simpleNudge.category),
      icon: _getIconString(simpleNudge.spec.title),
      isActive: simpleNudge.status == SimpleNudgeStatus.active,
      createdAt: simpleNudge.createdAt,
      type: _getNudgeType(simpleNudge.category),
      createdBy: userId,
      status: _convertStatus(simpleNudge.status),
      streak: simpleNudge.streak,
      isAIGenerated: simpleNudge.isAIGenerated,
    );
  }

  static Future<List<Nudge>> getComplexNudgesByCategory(NudgeCategory category, String userId) async {
    final simpleNudges = await getNudgesByCategory(category);
    return simpleNudges.map((nudge) => convertToComplexNudge(nudge, userId)).toList();
  }

  static String _getCategoryString(NudgeCategory category) {
    switch (category) {
      case NudgeCategory.personal:
        return 'personal';
      case NudgeCategory.family:
        return 'family';
      case NudgeCategory.friends:
        return 'friends';
      case NudgeCategory.work:
        return 'work';
    }
  }

  static String _getIconString(String title) {
    final lower = title.toLowerCase();
    if (lower.contains('water')) return 'water_drop';
    if (lower.contains('sleep')) return 'bedtime';
    if (lower.contains('exercise')) return 'fitness_center';
    if (lower.contains('study')) return 'book';
    if (lower.contains('meditat')) return 'self_improvement';
    return 'task_alt';
  }

  static NudgeType _getNudgeType(NudgeCategory category) {
    switch (category) {
      case NudgeCategory.personal:
        return NudgeType.personal;
      case NudgeCategory.family:
        return NudgeType.group;
      case NudgeCategory.friends:
        return NudgeType.friend;
      case NudgeCategory.work:
        return NudgeType.group;
    }
  }

  static NudgeStatus _convertStatus(SimpleNudgeStatus status) {
    switch (status) {
      case SimpleNudgeStatus.active:
        return NudgeStatus.active;
      case SimpleNudgeStatus.paused:
        return NudgeStatus.paused;
      case SimpleNudgeStatus.completed:
        return NudgeStatus.completed;
    }
  }

  static Future<void> updateNudgeStatus(String id, SimpleNudgeStatus newStatus) async {
    final nudges = await getAllNudges();
    final index = nudges.indexWhere((nudge) => nudge.id == id);
    
    if (index != -1) {
      final updatedNudge = SimpleNudge(
        id: nudges[index].id,
        spec: nudges[index].spec,
        createdAt: nudges[index].createdAt,
        status: newStatus,
        streak: nudges[index].streak,
        category: nudges[index].category,
        isAIGenerated: nudges[index].isAIGenerated,
      );
      
      nudges[index] = updatedNudge;
      await _saveNudges(nudges);
    }
  }

  static Future<void> deleteNudge(String id) async {
    final nudges = await getAllNudges();
    nudges.removeWhere((nudge) => nudge.id == id);
    await _saveNudges(nudges);
  }
}